mkdir Release
mcs @Linux.rsp
