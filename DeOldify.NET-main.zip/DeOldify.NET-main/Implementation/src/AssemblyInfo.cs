﻿//*************************************************************************************************
//* (C) ColorfulSoft corp., 2021. All Rights reserved.
//*************************************************************************************************

using System.Reflection;

[assembly: AssemblyTitle("DeOldify.NET")]
[assembly: AssemblyDescription("BW image colorization")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyVersion("1.0")]
[assembly: AssemblyCompany("ColorfulSoft")]
[assembly: AssemblyProduct("DeOldify.NET")]
[assembly: AssemblyCopyright("© Gleb S. Brykin")]
[assembly: AssemblyTrademark("DeOldify.NET")]
[assembly: AssemblyCulture("")]